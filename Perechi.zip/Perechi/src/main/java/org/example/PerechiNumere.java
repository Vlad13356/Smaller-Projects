package org.example;

public class PerechiNumere {

    private int numar1;
    private int numar2;


    public PerechiNumere(int numar2, int numar1) {
        this.numar2 = numar2;
        this.numar1 = numar1;
    }

    public PerechiNumere() {
    }

    public int getNumar1() {
        return numar1;
    }

    public void setNumar1(int numar1) {
        this.numar1 = numar1;
    }

    public int getNumar2() {
        return numar2;
    }

    public void setNumar2(int numar2) {
        this.numar2 = numar2;
    }

    @Override
    public String toString() {
        return "PerechiNumere{" +
                "numar1=" + numar1 +
                ", numar2=" + numar2 +
                '}';
    }
    public int nrCifrePare(int n) {
        n = Math.abs(n);
        int count = 0;
        while (n > 0) {
            if ((n % 10) % 2 == 0) count++;
            n /= 10;
        }

        System.out.println("n = " + count);
        return count;
    }
}
