package org.example;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MainApp {

    public static List<PerechiNumere> citire() {

        try {
            File file = new File("src/main/resources/PerechiIntroduse.json");
            ObjectMapper mapper = new ObjectMapper();
            List<PerechiNumere> numeres=mapper.readValue(file, new TypeReference<List<PerechiNumere>>() {});
            return numeres;
        }catch (IOException e){e.printStackTrace();}

        return null;

    }

    public static void scriere(List<PerechiNumere> numeres) {
        try {
            File file = new File("src/main/resources/AfisareNumere.json");
            ObjectMapper mapper = new ObjectMapper();
            mapper.writeValue(file, numeres);
        }catch (IOException e){e.printStackTrace();}

    }

    public static void main(String[] args) {

        List<PerechiNumere> perechiNumere = new ArrayList<>();
        perechiNumere=citire();
        scriere(perechiNumere);

        for (PerechiNumere P: perechiNumere)
        {
            System.out.println(P);
            P.nrCifrePare(5);
        }




    }
}
