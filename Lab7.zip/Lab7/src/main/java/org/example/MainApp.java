package org.example;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import java.io.File;
import java.io.IOException;
import java.sql.SQLOutput;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class MainApp {
    public static void stergere(Map<Integer, Carte> cartes,int id)
    {

        cartes.remove(id);
    }
    public static void scriere(Map<Integer, Carte> cartes) {
        try {
            ObjectMapper mapper=new ObjectMapper();
            mapper.enable(SerializationFeature.INDENT_OUTPUT);
            File file=new File("src/main/resources/carti.json");
            mapper.writeValue(file,cartes);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static Map<Integer,Carte> citire() throws IOException {
        File file=new File("src/main/resources/carti.json");
        ObjectMapper mapper=new ObjectMapper();
        Map<Integer,Carte> carti=mapper.readValue(file, new TypeReference<Map<Integer, Carte>>() {});
        return carti;
    }


    public static void main(String[] args) throws IOException {
      Map<Integer,Carte > carti= citire();

      for(Map.Entry<Integer,Carte> entry:carti.entrySet()){
            System.out.println(entry.getKey()+": "+entry.getValue());
        }

      Scanner sc=new Scanner(System.in);
      System.out.println("Introduceti Cartea pe care doriti sa o stergeti");
        int id;
        id=sc.nextInt();

      stergere(carti,id);
      carti.putIfAbsent(8,new Carte("Marea apararea","Brinzan",2001));
      for(Map.Entry<Integer,Carte> entry:carti.entrySet()){
          System.out.println(entry.getKey()+": "+entry.getValue());
      }
        scriere(carti);

    }
}
